; 智历 v2.0 Inno Setup 安装脚本
; 使用方法：用 Inno Setup Compiler 打开此文件并点击编译

#define MyAppName "智历"
#define MyAppNameEN "ZhiLi"
#define MyAppVersion "2.0"
#define MyAppPublisher "西安电子科技大学 网络与信息安全学院"
#define MyAppURL "https://github.com/yourname/ZhiLi"
#define MyAppExeName "ZhiLi.exe"

[Setup]
AppId={{B8F3A2D1-7C4E-4F5A-9E1B-3D6C8A2F5E7D}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppVerName={#MyAppName} v{#MyAppVersion}
AppPublisher={#MyAppPublisher}
AppPublisherURL={#MyAppURL}
AppSupportURL={#MyAppURL}
DefaultDirName={autopf}\{#MyAppNameEN}
DefaultGroupName={#MyAppName}
AllowNoIcons=yes
OutputDir=installer_output
OutputBaseFilename=ZhiLi_v2_Setup
SetupIconFile=icon.ico
Compression=lzma2/ultra64
SolidCompression=yes
WizardStyle=modern
PrivilegesRequired=lowest
DisableProgramGroupPage=yes

; 安装界面语言
[Languages]
Name: "english"; MessagesFile: "compiler:Default.isl"

; 安装内容
[Files]
Source: "dist\ZhiLi\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs

; 创建桌面图标和开始菜单
[Icons]
Name: "{autodesktop}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"; IconFilename: "{app}\icon.ico"; Comment: "AI智能简历诊断平台"
Name: "{group}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"; IconFilename: "{app}\icon.ico"
Name: "{group}\卸载 {#MyAppName}"; Filename: "{uninstallexe}"

; 安装完成后运行
[Run]
Filename: "{app}\{#MyAppExeName}"; Description: "启动 {#MyAppName}"; Flags: nowait postinstall skipifsilent

; 注册表（可选，用于添加卸载信息）
[Registry]
Root: HKCU; Subkey: "Software\{#MyAppNameEN}"; ValueType: string; ValueName: "InstallPath"; ValueData: "{app}"; Flags: uninsdeletekey
