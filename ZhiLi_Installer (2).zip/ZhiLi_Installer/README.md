# 智历 v2.0 - 安装包制作指南

## 最终效果
制作完成后你会得到一个 `ZhiLi_v2_Setup.exe` 安装程序，双击安装后：
- ✅ 安装向导界面（选择安装路径等）
- ✅ 桌面快捷方式
- ✅ 开始菜单中的快捷方式
- ✅ 控制面板中可卸载
- ✅ 有应用图标

## 制作步骤（只需点点鼠标）

### 第一步：打包exe
1. 双击 `step1_build_exe.bat`
2. 等待 1-3 分钟（自动安装依赖、生成图标、打包exe）
3. 看到"成功"提示后进入下一步

### 第二步：生成安装包
1. 先安装 Inno Setup（免费软件）
   - 下载地址: https://jrsoftware.org/isdl.php
   - 选第一个链接下载，安装时一路下一步
2. 双击 `step2_make_installer.bat`
3. 等待编译完成
4. 在 `installer_output` 文件夹中找到 `ZhiLi_v2_Setup.exe`

### 完成！
`ZhiLi_v2_Setup.exe` 就是最终的安装程序，可以：
- 发给同学/老师直接安装使用
- 答辩时展示专业的安装流程
- 上传到GitHub Releases

## 文件说明
```
ZhiLi_Installer/
├── step1_build_exe.bat    ← 第一步：双击打包exe
├── step2_make_installer.bat ← 第二步：双击生成安装包
├── setup.iss              ← Inno Setup 配置文件
├── make_icon.py           ← 图标生成脚本
├── app.py                 ← 主程序
├── index.html             ← 前端界面
└── README.md              ← 本说明
```

## 环境要求
- Windows 10/11
- Python 3.8+
- Inno Setup 6（免费，第二步需要）
